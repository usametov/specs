package specs2

/**
 * runner ouputing results in the Console
 */
object run extends org.specs2.runner.ClassRunner