package org.specs2

import runner.FilesRunner

/**
 * This top-level object can be used to execute Specifications found in the source directory
 */
object files extends FilesRunner