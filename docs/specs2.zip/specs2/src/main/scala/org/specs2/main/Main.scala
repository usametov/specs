package org.specs2
package main

private[specs2]
trait Main {
  def main(args: Array[String]): Unit
}
