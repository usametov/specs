======================================
Installation instructions
======================================

You need to download and install Maven 2.0.9.
Then execute the following command:

> mvn install

This will download the necessary dependent jars, build specs-<VERSION>.jar and install it in your local repository (you can also get the built jar in the target directory created by Maven at the root of your specs checkout).

For more instructions about using specs and its dependencies, please refer to the website: 

http://code.google.com/p/specs/wiki/RunningSpecs

Thanks!

Eric.