package acceptance

import bootstrap.liftweb.Boot
import net.liftweb.mapper.NotNullRef
import com.pocketchangeapp.model.User
import java.util. {TimeZone, Locale}

object Database {
  def cleanup() = {
    new Boot().boot
    User.bulkDelete_!!(NotNullRef(User.id))
  }

  def saveUser() = {
    cleanup()
    User.create.firstName("Eric").
                lastName("Torreborre").
                locale("en_AU").
                timezone("Australia/Sydney").
                email("me@dot.com").
                password("password").
                validated(true).save
  }

}