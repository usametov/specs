package org.specs2
package html

import org.openqa.selenium._

case class HtmlUnitDriver(driver: WebDriver = new htmlunit.HtmlUnitDriver, args: DriverArgs = DriverArgs()) extends Driver {
  def copyDriver(a: DriverArgs) = copy(args = a)
}
case class FirefoxDriver(driver: WebDriver = new firefox.FirefoxDriver, args: DriverArgs = DriverArgs()) extends Driver {
  def copyDriver(a: DriverArgs) = copy(args = a)
}
case class InternetExplorerDriver(driver: WebDriver = new ie.InternetExplorerDriver, args: DriverArgs = DriverArgs()) extends Driver {
  def copyDriver(a: DriverArgs) = copy(args = a)
}
case class ChromeDriver(driver: WebDriver = new chrome.ChromeDriver, args: DriverArgs = DriverArgs()) extends Driver {
  def copyDriver(a: DriverArgs) = copy(args = a)
}
